//Sean Lacey, 18902826, sean.lacey@ucdconnect.ie

#include <stdio.h>
#include <stdlib.h>
#include <string.h> //for strtok
#include <unistd.h> //for execve
#include <sys/wait.h> //for wait() command in fork usage
#include <signal.h> //for use of signals in catching ctrl C and errors
#include <time.h> //time library for printing date and time with the prompt
#include <sys/types.h> //for file duplication from stdout and directory permissions
#include <sys/stat.h>  //^
#include <fcntl.h>     //^
#include "shell.h" //for the prototypes of functions I created for this shell
#include "printPrompt.c"

/* Steps from the lecture slide
 * 1) Print prompt
 * 2) Read line from stdin
 * 3) Perform parsing on the string (seperate redirected and pipes, separate builtins)
 * 4) Execute command, system call execve
 * 5) Wait
 * 6) Go back to 1 eg end of loop
 */

int main(void)
{
  commandLoop();

  return EXIT_SUCCESS;
}

int commandLoop()
{

  int bytes_read;
  long unsigned int size = 10;
  char *string = NULL;

  string = (char *) malloc(size);

  int status;

  while(1)
  {
    //printing shell prompt
    printPrompt();
    fflush(stdout);

    if(signal(SIGINT, sig_handler) == SIG_ERR)
      printf("\ncan't catch SIGINT\n");

    //reading input
    bytes_read = getline(&string, &size, stdin);

    //parsing input using strtok
    int argc = 0;
    char **argv = malloc(sizeof(char*));
    char* temp = strtok(string, " ");

    while(temp != NULL)
    {
      argv[argc] = temp;
      argc++; //the number of string we have in argv
      argv = realloc(argv, (argc + 1) * sizeof(char*));
      temp = strtok(NULL, " ");
    }
    argv[argc] = temp;

    char *pos; //trimming the trailing newline from getline()
    if((pos=strchr(argv[argc-1], '\n')) != NULL)
    {
      *pos = (char) 0;
    }

    if(!(argc >= 1))
    {
      printf("Error: Not enough arguments!\n");
    }

    //checking if the user is trying the command "cd"
    if(!strcmp(argv[0], "cd"))
    {
      char s[100];
      chdir(argv[1]);
      printf("%s\n", getcwd(s, 100));
    }
    else if(!strcmp(argv[0], "exit"))
    {
      exit(0);
    }
    else
    {
      int forkNum = fork();
      int childStatus;

      if(!forkNum) //for the child case to execute
      {
        execvp(argv[0], argv);
        printf("Unknown command.\n");
        exit(1);
      }
      else
      {
        signal(SIGINT, SIG_IGN);
        wait(&childStatus);
        signal(SIGINT, SIG_DFL);
      }
    }

    for(int i=0; i<argc; i++)
    {
      if(argv[argc] == ">")
      {
        int f = open(argv[argc+1], O_CREAT);
        dup2(f, 1);
      }
    }
  }
}
