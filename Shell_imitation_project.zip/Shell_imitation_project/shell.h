//Sean Lacey, 18902826, sean.lacey@ucdconnect.ie

int commandLoop();

void printPrompt();

void sig_handler(int signo)
{
  if (signo == SIGINT)
  {
    printf("\n");
    printPrompt();
    fflush(stdout);
  }
}
