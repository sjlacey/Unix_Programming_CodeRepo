//Sean Lacey, 18902826, sean.lacey@ucdconnect.ie

void printPrompt()
{
  time_t now;
  time(&now);
  struct tm *local = localtime(&now);
  int day = local->tm_mday;
  int month = local->tm_mon;

  int hours = local->tm_hour;
  int minutes = local->tm_min;

  printf("[%02d/%02d %02d:%02d]# ", day, month+1, hours, minutes);
}
